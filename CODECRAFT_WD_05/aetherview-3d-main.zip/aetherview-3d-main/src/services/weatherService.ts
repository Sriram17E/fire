import { supabase } from '@/integrations/supabase/client';

export interface WeatherData {
  location: string;
  country: string;
  temperature: number;
  feelsLike: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  description: string;
  icon: string;
}

const parseWeatherData = (data: any): WeatherData => {
  return {
    location: data.name,
    country: data.sys.country,
    temperature: Math.round(data.main.temp),
    feelsLike: Math.round(data.main.feels_like),
    condition: data.weather[0].main,
    humidity: data.main.humidity,
    windSpeed: Math.round(data.wind.speed * 3.6), // Convert m/s to km/h
    description: data.weather[0].description,
    icon: data.weather[0].icon,
  };
};

export const fetchWeatherByCity = async (city: string): Promise<WeatherData> => {
  try {
    const { data, error } = await supabase.functions.invoke('fetch-weather', {
      body: { city },
    });

    if (error) {
      console.error('Error fetching weather data:', error);
      throw new Error('Failed to fetch weather data. Please check the city name.');
    }

    return parseWeatherData(data);
  } catch (error) {
    console.error('Error fetching weather data:', error);
    throw new Error('Failed to fetch weather data. Please check the city name.');
  }
};

export const fetchWeatherByCoords = async (lat: number, lon: number): Promise<WeatherData> => {
  try {
    const { data, error } = await supabase.functions.invoke('fetch-weather', {
      body: { lat, lon },
    });

    if (error) {
      console.error('Error fetching weather data:', error);
      throw new Error('Failed to fetch weather data.');
    }

    return parseWeatherData(data);
  } catch (error) {
    console.error('Error fetching weather data:', error);
    throw new Error('Failed to fetch weather data.');
  }
};
